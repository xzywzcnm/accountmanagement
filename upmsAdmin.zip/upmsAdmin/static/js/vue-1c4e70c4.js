import{ax as a}from"./@vue-76561cc2.js";a();
