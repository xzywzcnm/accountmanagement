import{f as o}from"./function-bind-f4350d04.js";var t=o.call(Function.call,Object.prototype.hasOwnProperty);export{t as s};
